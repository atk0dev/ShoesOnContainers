﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoesOnContainers.Services.ProductCatalogApi
{
    public class CatalogSettings
    {
        public string ExternalCatalogBaseUrl { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoesOnContainers.Services.ProductCatalogApi.Domain
{
    public class CatalogBrand
    {
        public int id { get; set; }
        public string Brand { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoesOnContainers.Web.WebMvc.ViewModels
{
    public class Header
    {
        public string Controller { get; set; }
        public string Text { get; set; }
    }
}
